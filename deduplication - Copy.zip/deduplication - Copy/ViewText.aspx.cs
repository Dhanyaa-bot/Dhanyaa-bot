﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ViewText : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();

    DataTable dtable = new DataTable();
    

    public void gridfill()
    {
        String str="select text_linking.linkingid,text_linking.fromusername, text_linking.tousername,textdata.textcontent from text_linking,textdata where text_linking.textdataid=textdata.textdataid and text_linking.tousername='"+Session["uname"].ToString()+"'";
         DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);

        //dtable.Columns.Add(new DataColumn("fromusername"));
        //dtable.Columns.Add(new DataColumn("tousername"));
        //dtable.Columns.Add(new DataColumn("textcontent"));


       // object[] rowvalues = new object[100];
        if (ds.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {

                ListBox1.Items.Add( ds.Tables[0].Rows[i]["fromusername"].ToString());
                ListBox2.Items.Add(ds.Tables[0].Rows[i]["tousername"].ToString());
                ListBox3.Items.Add(ds.Tables[0].Rows[i]["textcontent"].ToString());

                //rowvalues[0] = ds.Tables[0].Rows[i]["fromusername"].ToString();

                //rowvalues[1] = ds.Tables[0].Rows[i]["tousername"].ToString();
                //rowvalues[2] = ds.Tables[0].Rows[i]["textcontent"].ToString();

                //DataRow drow;
                //drow = dtable.Rows.Add(rowvalues);
                //dtable.AcceptChanges();

                //GridView1.DataSource = dtable;
                //GridView1.DataBind();

                //GridView1.Rows[i].Cells[1].Text =ds.Tables[0].Rows[i]["fromusername"].ToString();
                //GridView1.Rows[i].Cells[2].Text = ds.Tables[0].Rows[i]["tousername"].ToString();
                //GridView1.Rows[i].Cells[3].Text = ds.Tables[0].Rows[i]["textcontent"].ToString();
            }
            //GridView1.DataSource = ds;
            //GridView1.DataMember = "table";
            //GridView1.DataBind();
        }
        //String str1 = "select * from textdata where tousername='" + Session["uname"].ToString() + "'";
        ////DataSet ds1 = new DataSet();
        //ds = dl.GetDataSet(str1);
        //GridView2.DataSource = ds;
        //GridView2.DataMember = "table";
        //GridView2.DataBind();


        str = "select * from textdata where tousername='" + Session["uname"].ToString() + "'";
        DataSet ds1 = new DataSet();
        ds1 = dl.GetDataSet(str);
        if (ds1.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
            {
                ListBox1.Items.Add(ds1.Tables[0].Rows[i]["fromusername"].ToString());
                ListBox2.Items.Add(ds1.Tables[0].Rows[i]["tousername"].ToString());
                ListBox3.Items.Add(ds1.Tables[0].Rows[i]["textcontent"].ToString());
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
          if (!(Page.IsPostBack))
          {
              gridfill();
          }

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
}