/*
SQLyog Enterprise - MySQL GUI v8.12 
MySQL - 5.7.23-log : Database - collegecanteen
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`collegecanteen` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `collegecanteen`;

/*Table structure for table `food` */

DROP TABLE IF EXISTS `food`;

CREATE TABLE `food` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `canteen_id` varchar(5) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `is_deleted` int(5) DEFAULT '0' COMMENT '0-not deleted,1-deleted',
  `photo` blob,
  `day` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `food` */

insert  into `food`(`id`,`canteen_id`,`name`,`type`,`description`,`price`,`is_deleted`,`photo`,`day`) values (1,'c1','Biriyani','Veg','biriyani special.','70',0,'47273023460c72a363e4b3.jpg','Saturday'),(2,'c2','Idli Sambar','Veg','idli sambar','30',0,'125367409360c72abca09ff.jpg','Saturday'),(3,'c1','Burger','Nonveg','burger','40',0,'9458943506102977272714.jpg','Saturday'),(4,'c2','Noodles','Veg','noodles','40',0,'936750647610620d0b412b.jpg','Monday'),(5,'c2','Fried rice','Veg','fried rice','40',0,'8842887806106260eb1f83.jpg','Tuesday');

/*Table structure for table `orderr` */

DROP TABLE IF EXISTS `orderr`;

CREATE TABLE `orderr` (
  `cart_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) DEFAULT NULL,
  `food_id` int(5) DEFAULT NULL,
  `quantity` int(5) DEFAULT NULL,
  `totalcost` int(30) DEFAULT NULL,
  `deliveryaddress` varchar(30) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `is_ordered` int(5) DEFAULT '0' COMMENT '0-not ordered,1-ordered',
  `payment_mode` varchar(20) DEFAULT 'COD',
  `is_paid` varchar(5) DEFAULT 'no' COMMENT 'no-not paid,yes-paid',
  `ordered_date` date DEFAULT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `orderr` */

insert  into `orderr`(`cart_id`,`user_id`,`food_id`,`quantity`,`totalcost`,`deliveryaddress`,`date`,`is_ordered`,`payment_mode`,`is_paid`,`ordered_date`) values (1,1,1,5,350,'Mangalore','2021-07-31',1,'monthly','no','2021-07-31'),(2,1,3,6,240,'Mangalore','2021-07-31',1,'COD','no','2021-07-31'),(3,1,1,9,630,'Mangalore','2021-07-31',1,'UPI','yes','2021-07-31'),(4,1,2,10,300,'Karkala','2021-07-31',1,'monthly','no','2021-07-31'),(5,1,2,10,300,'Karkala','2021-07-31',0,'COD','no','2021-07-31');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(30) DEFAULT NULL,
  `contact_no` varchar(12) DEFAULT NULL,
  `email_id` varchar(30) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `otp` int(5) DEFAULT NULL,
  `is_verified` int(5) DEFAULT '0' COMMENT 'not verified-0,1-verified',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`id`,`user_name`,`contact_no`,`email_id`,`address`,`password`,`otp`,`is_verified`) values (1,'xyz','8088969962','suneethamoolya090@gmail.com','Mangalore','1234',4455,1),(12,'abcd','9999988888','abcd@gmail.com','hghj','789',9268,1),(13,'suneetha','5555566666','suneethamoolya@gmail.com','London','4567',8497,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
