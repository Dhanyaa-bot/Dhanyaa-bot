<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>College Canteen</title>
        <link href="static/css/bootstrap.min.css" type="text/css" rel="stylesheet">
        <link href="static/css/custom.css" type="text/css" rel="stylesheet">
    </head>
    <body style="background-image: url('static/images/image4.png');background-repeat: no-repeat;background-size: cover;">

        <nav class="navbar navbar-expand-md navbar-dark bg-primary">
            <a class="navbar-brand font-weight-bold" href="#">College Canteen</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault"
                    aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto ">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="admin/login.php">Canteen1</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="admin/login.php">Canteen2</a>
                    </li>
                </ul>
            </div>
        </nav>
    </body>
</html>
