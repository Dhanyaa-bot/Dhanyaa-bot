<script src="../static/js/jquery-3.4.1.min.js" type="text/javascript"></script>
<script src="../static/js/bootstrap.min.js" type="text/javascript"></script>



