<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>College Canteen</title>
    <link href="../static/css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="../static/css/custom.css" type="text/css" rel="stylesheet">
    <link href="../static/css/fonts.css" type="text/css" rel="stylesheet">
    <link href="../static/css/table.css" type="text/css" rel="stylesheet">
</head>

