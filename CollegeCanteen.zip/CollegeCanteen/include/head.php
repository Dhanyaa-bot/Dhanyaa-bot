<?php require_once '../include/config.php' ?>
<head>
    <title><?php echo PROJECT_NAME; ?></title>
    <link href="../static/css/bootstrap.min.css" rel="stylesheet">
    <link href="../static/css/dashboard.css" rel="stylesheet">
    <link href="../static/css/custom.css" rel="stylesheet">
</head>