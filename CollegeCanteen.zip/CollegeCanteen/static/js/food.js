$(function () {

    $('#btnaddfood').click(function (evt) {
        evt.preventDefault();

//        var canteen_id = $('#canteen_id').val();
        var food_name = $('#food_name').val();
        var food_type = $('#food_type').val();
        var food_desc = $('#food_desc').val();
        var food_price = $('#food_price').val();
        var day = $('#day').val();
        var image = $('#image').val();

//        if (canteen_id === "Choose Canteen Type...") {
//            alert("Please Choose Canteen Type");
//            return false;
//        }
        if (food_name === "") {
            alert("Please enter food name");
            return false;
        }
        if (food_type === "Choose Food Type...") {
            alert("Please enter food type");
            return false;
        }

        if (food_desc === "") {
            alert("Please enter food description");
            return false;
        }

        if (food_price === "") {
            alert("Please enter food price");
            return false;
        }
        if (day === "Choose Day...") {
            alert("Please Choose Day!");
            return false;
        }
        if (image === "") {
            alert("Please upload a food image");
            return false;
        }
        $.ajax({

            url: $('#form_add_food').prop('action'),
            type: $('#form_add_food').prop('method'),
            data: new FormData($('#form_add_food')[0]),
            contentType: false,
            processData: false,
            success: function (data, textStatus, jqXHR) {
                if (data.success) {
                    alert(data.body);
                    location.reload();
                    window.location = 'food_view.php';
                } else {
                    alert(data.error);

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });
});