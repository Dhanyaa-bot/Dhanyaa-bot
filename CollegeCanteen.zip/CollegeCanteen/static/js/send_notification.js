function    send_notification(mail) {
    $mail_id = mail;
    const button = document.querySelector('#btn');
//    button.disabled = true;

    if (!confirm("Are you sure?")) {
        return false;
    }
    $.ajax({
        url: "action.php",
        type: "post",
        dataType: 'json',
        data: {"mail": $mail_id, "command": "sendmail"},

        success: function (data, textStatus, jqXHR) {

            if (data.success) {
                alert(data.body);
                location.reload();
            } else {
                alert(data.error);
            }

        },

        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        }
    });



}