$(function () {

    $('#btnupdatefood').click(function (evt) {
        evt.preventDefault();


        var fd_name = $('#fd_name').val();
        var fd_type = $('#fd_type').val();
        var fd_desc = $('#fd_desc').val();
        var fd_day = $('#fd_day').val();
        var fd_price = $('#fd_price').val();

        if (fd_name === "") {
            alert("Please enter food name");
            return false;
        }

        if (fd_type === "Choose Food Type...") {
            alert("Please Choose food type");
            return false;
        }
        if (fd_desc === "") {
            alert("Please enter food description");
            return false;
        }


        if (fd_day === "Choose Day...") {
            alert("Please Choose Day");
            return false;
        }
        if (fd_price === "") {
            alert("Please enter food price");
            return false;
        }
        $.ajax({

            url: $('#form_upfood').prop('action'),
            type: $('#form_upfood').prop('method'),
            data: $('#form_upfood').serialize(),

            success: function (data, textStatus, jqXHR) {
                if (data.success) {
                    alert(data.body);
                    location.reload();
                    window.location = 'food_view.php';
                } else {
                    alert(data.error);

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });
});


function update_food(food_id) {
    if (food_id) {

        $.ajax({
            url: "action.php",
            type: 'GET',
            data: {
                command: 'getFoodDetails',
                foodup_id: food_id
            },
            success: function (data, textStatus, jqXHR) {
                if (data.success) {

                    var op = data.body;


                    $('#form_upfood')[0].reset();
                    $('#fd_id').val(op[0].id);
                    $('#fd_name').val(op[0].name);
                    $('#fd_type').val(op[0].type);
                    $('#fd_desc').val(op[0].description);
                    $('#fd_day').val(op[0].day);
                    $('#fd_price').val(op[0].price);
//                    $('#image').val(op[0].photo);

                    $('#modalUpdatefood').modal('show');

                } else {
                    alert(data.error);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });

    }
}

