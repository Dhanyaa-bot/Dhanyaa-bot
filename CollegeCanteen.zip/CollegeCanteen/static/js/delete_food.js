function    delete_Food(receiving_id) {
    $id = receiving_id;
    const button = document.querySelector('#btn');
//    button.disabled = true;

    if (!confirm("Are you sure?")) {
        return false;
    }
    $.ajax({
        url: "action.php",
        type: "post",
        dataType: 'json',
        data: {"food_id": $id, "command": "deleteFood"},

        success: function (data, textStatus, jqXHR) {

            if (data.success) {
                alert(data.body);
                location.reload();
            } else {
                alert(data.error);
            }

        },

        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        }
    });



}