function update_order(cart_id) {
    $id = cart_id;
    const button = document.querySelector('#paid_btn');
//    button.disabled = true;

    if (!confirm("Are you sure?")) {
        return false;
    }
    $.ajax({
        url: "action.php",
        type: "post",
        dataType: 'json',
        data: {"cart_id": $id, "command": "updateOrder"},

        success: function (data, textStatus, jqXHR) {

            if (data.success) {
                alert(data.body);
                location.reload();
            } else {
                alert(data.error);
            }

        },

        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        }
    });
}
