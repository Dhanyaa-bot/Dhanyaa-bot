////function showTable() {
////    $("#table").show();
////}
function validate() {

    var start_date = $('#start_date').val();
    var end_date = $('#end_date').val();
    var payment_type = $('#payment_type').val();

    if (start_date === "") {
        alert("Please enter start date");
        return false;
    }
    if (end_date === "") {
        alert("Please enter end date");
        return false;
    }
    if (payment_type === "Choose payment type...") {
        alert("Please enter payment type");
        return false;
    }
    return true;
}




