<?php

require_once '../admin/Response.php';
require_once '../db/db.php';



$con = new DB();
$res = array();
$cart_id = $_POST['cart_id'];
$iss_ordered = $_POST['is_ordered'];
$ordered_date = date("Y-m-d");
$payment = $_POST['payment_mode'];
$sql = "UPDATE orderr SET is_ordered='$iss_ordered',ordered_date='$ordered_date',payment_mode='$payment' WHERE cart_id='$cart_id'";
$res = $con->executeUpdate($sql);
if (!empty($res)) {
    $response = array("key" => "Success");
}
echo json_encode($response);
