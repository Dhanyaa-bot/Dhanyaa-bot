<?php

require_once '../admin/Response.php';
require_once '../db/db.php';

$con = new DB();

$contact_no = $_POST['contact_no'];
$password = $_POST['password'];
$query = "SELECT * FROM user WHERE contact_no='$contact_no' AND password='$password'";
$user = $con->executeSelect($query);
if ($user != NULL) {
    $sql = "SELECT * FROM user WHERE contact_no='$contact_no' AND password='$password' AND is_verified='1'";
    $res = $con->executeSelect($sql);
    if ($res != NULL) {

        $response = array('id' => $res[0]['id'], 'name' => $res[0]['user_name'], 'email_id' => $res[0]['email_id'], 'server_res' => "success");
//        echo json_encode($response);
    } else {
        $response = array("server_res" => "not verified");
//    echo json_encode($response);
    }
} else {
    $response = array("server_res" => "Invalid credentials");
}
echo json_encode($response);
