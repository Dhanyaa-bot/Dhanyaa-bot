<?php

require_once '../admin/Response.php';
require_once '../db/db.php';


$con = new DB();

$user_id = $_GET['id'];
if ('c1' == $_GET['cant_type']) {
    $sql = "SELECT * FROM orderr LEFT  JOIN food ON orderr.food_id=food.id WHERE user_id='$user_id' AND canteen_id='c1' AND is_ordered='0'";
    $result = $con->executeSelect($sql);
    echo json_encode($result);
} else {
    $sql = "SELECT * FROM orderr LEFT  JOIN food ON orderr.food_id=food.id WHERE user_id='$user_id' AND canteen_id='c2' AND is_ordered='0'";
    $result = $con->executeSelect($sql);
    echo json_encode($result);
}
