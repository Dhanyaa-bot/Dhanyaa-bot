<?php

require_once '../admin/Response.php';
require_once '../db/db.php';

$con = new DB();
if ($_POST['method'] == 'update_login') {
    $contact_no = $_POST['user_contact'];
    $password = $_POST['user_password'];
    $otp = $_POST['user_otp'];

    $query = "SELECT * FROM user WHERE contact_no='$contact_no' AND password='$password' AND otp='$otp'";
    $res = $con->executeSelect($query);

    if ($res != NULL) {
        $id = $res[0]['id'];
        $update = "UPDATE user SET is_verified='1' WHERE id='$id'";
        $result = $con->executeUpdate($update);
        $response = array('id' => $res[0]['id'], 'name' => $res[0]['user_name'], 'email_id' => $res[0]['email_id'], 'server_res' => "success");
//        echo json_encode($response);
    } else {
        $response = array("server_res" => "Invalid otp");
    }
    echo json_encode($response);
}
