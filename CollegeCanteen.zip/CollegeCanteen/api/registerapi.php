<?php

require_once '../admin/Response.php';
require_once '../db/db.php';
require_once '../include/mailer.php';
$con = new DB();

if ($_POST['method'] == 'register') {
    $sname = $_POST['reg_name'];
    $contact = $_POST['reg_contact'];
    $email = $_POST['reg_email'];
    $addresss = $_POST['reg_address'];
    $passwrd = $_POST['reg_password'];

    $query = "SELECT * FROM user WHERE email_id='$email'";
    $result = $con->executeSelect($query);
    if (empty($result)) {
        $sql = "INSERT INTO user(user_name,contact_no,email_id,address,password) VALUES('$sname','$contact','$email','$addresss','$passwrd')";
        $id = $con->executeInsertAndGetId($sql);
        $otp = rand(1000, 9999);
        $mailBody = "Your otp is $otp.";
        if ($id > 0) {
            $update = "UPDATE user SET otp='$otp' WHERE id='$id'";
            $res = $con->executeUpdate($update);
            sendMail("OTP", $mailBody, $email);
            $response = array("key" => "Success");
        }
    } else {
        $response = array("key" => "Registered");
    }
}
echo json_encode($response);
