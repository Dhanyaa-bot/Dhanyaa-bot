<?php

require_once '../admin/Response.php';
require_once '../db/db.php';


$con = new DB();


$userid = $_POST['id'];
$food_id = $_POST['food_id'];
$quantity = $_POST['food_quantity'];
$cost = $_POST['food_cost'];
$total = $_POST['food_total'];
$address = $_POST['del_address'];
$date = date("Y-m-d");
$ordered_date = date("Y-m-d");
$sql = "INSERT INTO orderr(user_id,food_id,quantity,totalcost,deliveryaddress,date,ordered_date) VALUES('$userid','$food_id','$quantity','$total','$address','$date','$ordered_date')";
$id = $con->executeInsertAndGetId($sql);
if ($id > 0) {
    $response = array("key" => "Success");
}
echo json_encode($response);
