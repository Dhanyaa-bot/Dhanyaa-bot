<?php

require_once './../db/db.php';
require_once '../include/mailer.php';
$con = new DB();

$email = $_GET['email'];
$my = 'suneethamoolya090@gmail.com';
$sql = "SELECT * FROM user WHERE email_id='$email'";
$res = $con->executeSelect($sql);


if (!empty($res)) {
    $pass = $res[0]['password'];
    $mailBody = "Your password is $pass.";
    if (sendMail("Recovery password", $mailBody, $my)) {
        $response = array("key" => "Success");
    } else {
        $response = array("key" => "email not sent");
    }
}
echo json_encode($response);

