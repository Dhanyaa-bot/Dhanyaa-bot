<?php

require_once '../admin/Response.php';
require_once '../db/db.php';


$con = new DB();

if ('c1' == $_GET['type']) {
    $today = date("l");
    $sql = "SELECT * FROM food WHERE canteen_id='c1' AND is_deleted='0' AND day='$today'";
    $result = $con->executeSelect($sql);
    $response = array();
    echo json_encode($result);
} else {
    $today = date("l");
    $sql = "SELECT * FROM food WHERE canteen_id='c2' AND is_deleted='0' AND day='$today'";
    $result = $con->executeSelect($sql);
    $response = array();
    echo json_encode($result);
}
?>
