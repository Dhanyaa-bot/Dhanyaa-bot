<?php
require_once '../db/db.php';
require_once './home.php';
require_once '../include/header.php';
$cant_id = $_SESSION['canteen'];
$query = "SELECT * FROM  food WHERE is_deleted=0 AND canteen_id='$cant_id'";
$con = new DB();
$food = $con->executeSelect($query);
?>
<html>
    <?php
    ?>

    <body>
        <div class="container">
            <div class="row">


                <table class="table table-bordered table-striped table-sm ml-5 mt-5" style="width: 100%;">
                    <form id="form_id" method="post">
                        <input type="hidden" name="command" id="command" value="val"/>
                        <thead>
                            <tr style="background-color: skyblue">
                                <th>id</td>
                                <th>Food Name</th>
                                <th>Food Type</th>
                                <th>Food Description</th>
                                <th>Food Price</th>
                                <th>Day</th>
                                <th>Photo</th>
                                <th colspan="2" style="text-align: center">Action</th>

                            </tr>
                        </thead>
                        <?php
                        $i = 0;
                        foreach ($food as $fd) {
                            ++$i;
                            ?>
                            <tr  style="background-color: black">
                                <td><?php echo "$fd[id]" ?></td>
                                <td><?php echo "$fd[name]" ?></td>
                                <td><?php echo "$fd[type]" ?></td>
                                <td><?php echo"$fd[description]" ?></td>
                                <td><?php echo "$fd[price]" ?></td>
                                <td><?php echo "$fd[day]" ?></td>
                                <td><img src=../images/<?php echo "$fd[photo]" ?> class="rounded-circle" alt="photo" height="50" width="50"></td>
                                <td align="center" ><button type="button" id="btn" class="btn btn-sm btn-primary mt-2" onclick="update_food(<?php echo "$fd[id]" ?>);">Update</button></td>
                                <td align="center"><button type="button"  id="btn" class="btn btn-sm btn-primary mt-2" onclick="delete_Food(<?php echo "$fd[id]" ?>);">Delete</button></td>
                            </tr>
                            <?php
                        }
                        if ($i == 0) {
                            ?>
                            <tr>
                                <td colspan="100%" class="alert alert-danger text-center">
                                    No records
                                </td>
                            </tr>
                        <?php }
                        ?>
                    </form>
                </table>

            </div></div>

        <?php require_once '../include/footer.php'; ?>

        <script src="../static/js/update_food.js"></script>
        <script src="../static/js/delete_food.js"></script>

    </body></html>