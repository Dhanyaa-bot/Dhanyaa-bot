<?php
require_once '../db/db.php';
require_once './home.php';
require_once '../include/header.php';
$cant_id = $_SESSION['canteen'];
$account = '';
$con = new DB();
if (isset($_POST['command']) == 'add_account') {

    $start = $_REQUEST['start_date'];
    $end = $_REQUEST['end_date'];
    $payment_type = $_REQUEST['payment_type'];

    $query = "SELECT * FROM orderr JOIN USER ON user.id=orderr.user_id JOIN food ON food.id=orderr.food_id WHERE date BETWEEN '$start' AND '$end' AND payment_mode='$payment_type' AND canteen_id='$cant_id'";

    $account = $con->executeSelect($query);
}
?>
<html>
    <?php
    ?>

    <body>
        <div class="row justify-content-center">

            <div class="col-mx-4 my-2">
                <div class="card" style="width: 50rem;height: 12rem;background-color:skyblue">
                    <div class="card-body">


                        <form class="row g-3 mx-3" method="post" action="#" id="form_account" onsubmit="return validate()" >
                            <input type="hidden" name="command" id="command" value="add_account"/>
                            <div class="col-md-6">
                                <label for="start_date" class="form-label">Enter start date</label>
                                <input type="date" class="form-control" id="start_date" name="start_date" />
                            </div>
                            <div class="col-md-6">
                                <label for="end_date" class="form-label" >Enter end date</label>
                                <input type="date"  id="end_date" name="end_date" class="form-control" />
                            </div>
                            <div class="col-md-8 my-2">
                                <label for="payment_type" class="form-label mt-2" >Payment Type</label>
                                <select id="payment_type" name="payment_type" class="form-control">
                                    <option selected>Choose payment type...</option>
                                    <option>COD</option>
                                    <option>monthly</option>
                                    <option>UPI</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class="btn-primary btn-sm mt-5 px-5" id="search_btn"  name="search_btn" >Search</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>

        </div>
        <div  class="mx-5">


            <table class="table table-bordered table-striped table-sm ml-1 mt-2" style="width: 100%;">
                <form id="form_id" method="post">
                    <input type="hidden" name="command" id="command" value="val"/>
                    <thead>
                        <tr style="background-color: skyblue">
                            <th>#</th>
                            <th>User Name</th>
                            <th>Food Name</th>
                            <th>Total Price</th>
                            <th>Date</th>
                            <th>Status</th>



                        </tr>
                    </thead>
                    <?php
                    $i = 0;
                    if (!empty($account)) {


                        foreach ($account as $row) {
                            ?>
                            <tr style="background-color: black">
                                <td><?php echo ++$i; ?></td>
                                <td><?php echo "$row[user_name]" ?> </td>
                                <td><?php echo "$row[name]" ?> </td>
                                <td><?php echo "$row[totalcost]" ?> </td>
                                <td><?php echo "$row[date]" ?></td>

                                <?php
                                echo '';
                                $status = $row['is_paid'];
                                if ($status == 'yes') {
                                    ?>
                                    <td class="text-center"><button type="button" class="btn btn-light btn-sm px-4" disabled>Paid</button>

                                        <?php
                                    }
                                    if ($status == 'no') {
                                        ?>
                                    <td class="text-center"><button type="button" class="btn-primary btn-sm">Not Paid</button>
                                    <?php } ?>
                            </tr>
                            <?php
                        }
                    }
                    if ($i == 0) {
                        ?>
                        <tr>
                            <td colspan="100%" class="alert alert-danger text-center">
                                No records
                            </td>
                        </tr>
                    <?php }
                    ?>

                </form>
            </table>

        </div>

        <?php require_once '../include/footer.php'; ?>
        <script src="../static/js/account.js"></script>
    </body></html>

