<?php

session_start();

require_once './Response.php';
require_once './../db/db.php';
require_once '../vendor/autoload.php';
require_once '../include/util.php';
require_once '../include/mailer.php';
$con = new DB();
$response = new Response();

try {

    if (isset($_POST['command'])) {
        $command = $_POST['command'];
        if ('addfood' == $command) {
            $image = uploadImage('image');
            $canteen_id = $_SESSION["canteen"];
            $f_name = $_REQUEST['food_name'];
            $f_type = $_REQUEST['food_type'];
            $f_desc = $_REQUEST['food_desc'];
            $f_day = $_REQUEST['day'];
            $f_price = $_REQUEST['food_price'];
            $sql = "INSERT INTO food(canteen_id,name,type,description,price,photo,day) VALUES('$canteen_id','$f_name','$f_type','$f_desc','$f_price','$image','$f_day')";
            $res = $con->executeInsertAndGetId($sql);
            if ($res > 0) {
                $response->success("Completed successfully...");
            } else {
                throw new Exception("Something went wrong...");
            }
        } elseif ('deleteFood' == $command) {
            $id = $_POST['food_id'];
            $sql = "UPDATE food SET is_deleted=1 WHERE id=$id";
            $res = $con->executeUpdate($sql);
            if ($res > 0) {
                $response->success("Completed successfully...");
            } else {
                throw new Exception("Something went wrong...");
            }
        } elseif ('updateOrder' == $command) {
            $id = $_POST['cart_id'];
            $sql = "UPDATE orderr SET is_paid='yes' WHERE cart_id=$id";
            $res = $con->executeUpdate($sql);
            if ($res > 0) {
                $response->success("Completed successfully...");
            } else {
                throw new Exception("Something went wrong...");
            }
        } elseif ('updatefood' == $command) {

            $f_id = $_REQUEST['fd_id'];
            $f_name = $_REQUEST['fd_name'];
            $f_type = $_REQUEST['fd_type'];
            $f_desc = $_REQUEST['fd_desc'];
            $f_day = $_REQUEST['fd_day'];
            $f_price = $_REQUEST['fd_price'];
            $cant_id = $_SESSION["canteen"];
            $sql = "UPDATE food SET name='$f_name',type='$f_type',description='$f_desc',price='$f_price',day='$f_day' WHERE canteen_id='$cant_id' AND id='$f_id'";
            $res = $con->executeUpdate($sql);
            if ($res > 0) {
                $response->success("Completed successfully...");
            } else {
                throw new Exception("Something went wrong...");
            }
        } elseif ('sendmail' == $command) {

            $email = $_POST['mail'];
            $mailbody = "Your food is prepared,please collect it.";

            if (sendMail("Ordered Food Status", $mailbody, $email)) {
                $response->success("Completed successfully...");
            } else {
                throw new Exception("Something went wrong...");
            }
        }
    } elseif (isset($_GET['command'])) {
        $command = $_GET['command'];
        if ('getFoodDetails' == $command) {
            $food_id = $_GET['foodup_id'];
            $sql = "SELECT * FROM food WHERE id='$food_id'";
            $res = $con->executeSelect($sql);
            if ($res > 0) {
                $response->success($res);
            } else {
                throw new Exception("Something went wrong...");
            }
        }
    }
} catch (Exception $ex) {
    $response->error($ex->getMessage());
}

$response->writeResponse();
