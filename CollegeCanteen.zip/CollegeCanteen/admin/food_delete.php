<?php
require_once '../db/db.php';
require_once './home.php';
require_once '../include/header.php';
$cant_id = $_SESSION['canteen'];
$query = "SELECT * FROM  food WHERE is_deleted=0 AND canteen_id='$cant_id'";
$con = new DB();
$food = $con->executeSelect($query);
?>
<html>
    <?php
    ?>

    <body>
        <div class="container">
            <div class="row">


                <table class="table table-bordered table-striped table-sm ml-5 mt-5" style="width: 100%;">
                    <form id="form_id" method="post">
                        <input type="hidden" name="command" id="command" value="val"/>
                        <thead>
                            <tr style="background-color: skyblue">
                                <th>id</th>
                                <th>Food Name</th>
                                <th>Food Type</th>
                                <th>Food Description</th>
                                <th>Food Price</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <?php
                        $i = 0;
                        foreach ($food as $fd) {
                            ++$i;
                            ?>
                            <tr style="background-color: black">
                                <td><?php echo "$fd[id]" ?></td>
                                <td><?php echo "$fd[name]" ?></td>
                                <td><?php echo "$fd[type]" ?></td>
                                <td><?php echo"$fd[description]" ?> </td>
                                <td><?php echo "$fd[price]" ?></td>

                                <td align="center"><button type="button" id="btn" class="btn-primary" onclick="delete_Food(<?php echo "$fd[id]" ?>);">Delete</button></td>
                            </tr>
                            <?php
                        }
                        if ($i == 0) {
                            ?>
                            <tr>
                                <td colspan="100%" class="alert alert-danger text-center">
                                    No records
                                </td>
                            </tr>
                        <?php }
                        ?>
                    </form>
                </table>

            </div></div>
        <?php require_once '../include/footer.php'; ?>



    </body></html>