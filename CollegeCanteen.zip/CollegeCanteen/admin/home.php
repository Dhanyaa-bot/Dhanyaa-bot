<?php
session_start();
?>

<html>
    <head>

    </head>

    <?php
    require_once '../include/header.php';
    ?>

    <body style="background-image: url('../static/images/image4.png');background-repeat: no-repeat;background-size: cover;">

        <nav class="navbar navbar-expand-lg navbar-dark bg-primary ">
            <a class="navbar-brand font-weight-bold" href="home.php">College Canteen</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" data-toggle="dropdown">
                            Manage Food
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="#" id="navbarDropdown" data-toggle="modal" data-target="#modalAddfood">Add</a>
                            <a class="dropdown-item" href="food_view.php" id="navbarDropdown">View</a>
                            <!--                            <a class="dropdown-item" href="food_delete.php" id="navbarDropdown">Delete</a>-->
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" data-toggle="dropdown">
                            Order Management
                        </a>
                        <div class="dropdown-menu">

                            <a class="dropdown-item" href="order_view.php" id="navbarDropdown">View</a>

                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" data-toggle="dropdown">
                            Account Management
                        </a>
                        <div class="dropdown-menu">

                            <a class="dropdown-item" href="account_view.php" id="navbarDropdown">View</a>

                        </div>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </nav>

        <!--addfood modal for ManageFood-->
        <div id="modalAddfood"  class="modal fade in" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content" >
                    <div class="modal-header">
                        <h4 class="modal-title">Add Food Details</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <div class="modal-body">

                        <form action="action.php" accept-charset=""enctype="multipart/form-data" method="post" id="form_add_food">
                            <input type="hidden" name="command" id="command" value="addfood"/>

<!--                            <select id="canteen_id" name="canteen_id" class="form-control">
                                <option selected>Choose Canteen Type...</option>
                                <option>c1</option>
                                <option>c2</option>
                            </select>-->
                            <input type="text-area" class="form-control mt-4" id="food_name" name="food_name" placeholder="Food name" /><br>

                            <select id="food_type" name="food_type" class="form-control">
                                <option selected>Choose Food Type...</option>
                                <option>Veg</option>
                                <option>Nonveg</option>
                            </select>
                            <textarea class="form-control mt-4" id="food_desc" name="food_desc" style="min-width: 100%" placeholder="Description"></textarea><br>
                            <input type="text-area" class="form-control" id="food_price" name="food_price" placeholder="Food Price" width="50"/><br>
                            <select id="day"  name="day" class="form-control mb-4">
                                <option selected>Choose Day...</option>
                                <option>Sunday</option>
                                <option>Monday</option>
                                <option>Tuesday</option>
                                <option>Wednesday</option>
                                <option>Thursday</option>
                                <option>Friday</option>
                                <option>Saturday</option>

                            </select>

                            <label>Choose image
                                File</label> <div class="form-group">
                                <input type="file" name="image" id="image"/>
                            </div>
                            <div class="form-group text-right">
                                <button type="submit" id="btnaddfood"
                                        class="btn btn-primary" name="btnaddfood">
                                    Add
                                </button>
                                <button type="reset" class="btn btn-primary">Reset</button>
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>

        <!--Updatefood modal for ManageFood-->
        <div id="modalUpdatefood"  class="modal fade in" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content" >
                    <div class="modal-header">
                        <h4 class="modal-title">Update Food Details</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <div class="modal-body">

                        <form action="action.php" accept-charset=""enctype="multipart/form-data" method="post" id="form_upfood">
                            <input type="hidden" name="command" id="command" value="updatefood"/>
                            <input type="hidden" name="fd_id" id="fd_id"/>
                            <label></label>
                            <input type="text-area" class="form-control" id="fd_name" name="fd_name" placeholder="Food name" /><br>
                            <!--<input type="text-area" class="form-control" id="fd_type" name="fd_type" placeholder="Food Type" /><br>-->
                            <select id="fd_type" name="fd_type" class="form-control">
                                <option>Choose Food Type...</option>
                                <option>Veg</option>
                                <option>Nonveg</option>
                            </select>
                            <textarea class="form-control mt-4" id="fd_desc" name="fd_desc" style="min-width: 100%" placeholder="Description"></textarea><br>
                            <select id="fd_day"  name="fd_day" class="form-control mb-4">
                                <option selected>Choose Day...</option>
                                <option>Sunday</option>
                                <option>Monday</option>
                                <option>Tuesday</option>
                                <option>Wednesday</option>
                                <option>Thursday</option>
                                <option>Friday</option>
                                <option>Saturday</option>

                            </select>
                            <input type="text-area" class="form-control" id="fd_price" name="fd_price" placeholder="Food Price" width="50"/><br>
                            <div class="form-group text-right">
                                <button type="submit" id="btnupdatefood"
                                        class="btn btn-primary" name="btnupdatefood">
                                    Update
                                </button>

                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>






        <?php require_once '../include/footer.php'; ?>

        <script src="../static/js/food.js"></script>

    </body>
</html>
