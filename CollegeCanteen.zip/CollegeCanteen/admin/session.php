<?php

session_start();

if (!isset($_SESSION['c1']) || !$_SESSION['login'] == true) {
    header("location: login.php?error=Please login!");
    die();
} elseif (!isset($_SESSION['c2']) || !$_SESSION['login'] == true) {
    header("location: login.php?error=Please login!");
    die();
}