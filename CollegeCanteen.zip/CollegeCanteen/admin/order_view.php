<?php
require_once '../db/db.php';
require_once './home.php';
require_once '../include/header.php';
$cant_id = $_SESSION['canteen'];
$query = "SELECT * FROM orderr LEFT  JOIN food ON orderr.food_id=food.id LEFT JOIN USER ON orderr.user_id=user.id WHERE canteen_id='$cant_id' AND is_paid='no'";
$con = new DB();
$order = $con->executeSelect($query);
?>
<html>
    <?php
    ?>

    <body>

        <div class = "mx-5">


            <table class = "table table-bordered table-striped table-sm ml-1 mt-5" style = "width: 100%;">
                <form id = "form_id" method = "post">
                    <input type = "hidden" name = "command" id = "command" value = "val"/>
                    <thead>
                        <tr style = "background-color: skyblue">
                            <th>id</td>

                            <th>Food Name</th>

                            <th>User Name</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                            <th>Delivery Address</th>
                            <th>Ordered Date</th>
                            <th>Payment Mode</th>
                            <th class = "text-center">Action</th>


                        </tr>
                    </thead>
<?php
$i = 0;
foreach ($order as $odr) {
    ++$i;
    ?>
                        <tr style="background-color: black">
                            <td><?php echo "$odr[cart_id]" ?></td>

                            <td><?php echo "$odr[name]" ?></td>

                            <td><?php echo "$odr[user_name]" ?></td>
                            <td><?php echo "$odr[quantity]" ?> </td>
                            <td><?php echo "$odr[totalcost]" ?> </td>
                            <td><?php echo "$odr[deliveryaddress]" ?> </td>
                            <td><?php echo "$odr[ordered_date]" ?></td>
                            <td><?php echo "$odr[payment_mode]" ?> </td>
                            <td class="text-center"><button type="button" id="send_btn" class="btn-primary btn-sm my-1" onclick="send_notification('<?php echo "$odr[email_id]" ?>');">Send notifcation</button>
                                <button type="button" id="paid_btn" class="btn-danger btn-sm px-4 my-1" onclick="update_order(<?php echo "$odr[cart_id]" ?>);">Pay</button></td>
                        </tr>
    <?php
}
if ($i == 0) {
    ?>
                        <tr>
                            <td colspan="100%" class="alert alert-danger text-center">
                                No records
                            </td>
                        </tr>
<?php }
?>
                </form>
            </table>

        </div>


<?php require_once '../include/footer.php'; ?>
        <script src="../static/js/update_order.js"></script>
        <script src="../static/js/send_notification.js"></script>
    </body></html>